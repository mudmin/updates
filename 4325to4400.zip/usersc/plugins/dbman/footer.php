<?php
// bold("<br>dbman Footer Loaded");
